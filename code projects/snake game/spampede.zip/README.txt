Spampede README.txt

Please complete the template below, replacing the text between 
the ** symbols with your own text.

Parts of the project completed/not completed:

   ** 
      Please indicate here what you completed and what (if any)
      parts of the project you did not complete.
   **

Known bugs:  

   ** 
      Please list any bugs that you have discovered in your programs.
      (Reporting bugs demonstrates you've tested your software -- as a
      result, it's a way to earn some of the credit for those features.)
   **

Extra features that were added:

   ** 
      If you added any bonus features, please describe them for us here
      and tell us how to use them when we play your game.
   ** 

(Optional) Comments about this project:

	 *Please tell us any thoughts you had on this project - what
	 you enjoyed or didn't enjoy, what was challenging, or anything else.*

