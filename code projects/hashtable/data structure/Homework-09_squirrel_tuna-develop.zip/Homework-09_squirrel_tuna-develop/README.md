# Overview

In this assignment, you'll implement the rest of the `ChunkyString` class. You'll also have the option to use that class in a program to model noisy message-passing.
 
# Grading
Your submission will be graded as follows: 
* 17 points: correctness
* 10 points: completeness
* 6 points: style 
* 6 points: elegance
* 6 points: clarity 

See the [Grading Guidelines](https://cs.hmc.edu/cs70/wiki/Grading-Guidelines) wiki page for more information about what we're looking for in each of those categories. 
