/*
 * \file chunkystring.cpp
 * \authors hmc-tuna-f18 and hmc-squirrel-f18
 * \brief Implemenation of chunkystring and its private classes.
*/

#include "chunkystring.hpp"
#include "testing-logger.hpp"
#include <list>
#include <algorithm>
using namespace std;

/*
* \brief Default constructor for a ChunkyString
* \details the chunkystring should have a size of 0 and
*          chunks_ is already initialized in the header file
*/
ChunkyString::ChunkyString()
 : size_(0)
{
 
}

/*
* \brief Default constructor for a Chunk, a struct of ChunkyString.
*
* \details the chunk is initialized with one character
* 
*/
ChunkyString::Chunk::Chunk(char first)
 : length_(1)
{
    chars_[0] = first;
}


/*
* \brief begin function of chunkystring
*
* \returns an iterator pointing to the first spot in the chunk
*/
ChunkyString::iterator ChunkyString::begin()
{
    return iterator(chunks_.begin(), 0);
}


/*
* \brief end function of chunkystring
*
* \returns an iterator pointing to the spot after the last one
*/
ChunkyString::iterator ChunkyString::end()
{
    return iterator(chunks_.end(), 0);
}


/*
* \brief cbegin function of chunkystring
*
* \returns a Constant iterator pointing to the first spot
*/
ChunkyString::const_iterator ChunkyString::cbegin() const
{
    return const_iterator(chunks_.begin(), 0);
}


/*
* \brief cend function of chunkystring
*
* \returns an constant iterator pointing to the spot after the last one
*/ 
ChunkyString::const_iterator ChunkyString::cend() const
{
    return const_iterator(chunks_.end(), 0);
}


/*
* \brief size funtion of ChunkyString
*
* \returns number of chars in the chunky string
*/ 
size_t ChunkyString::size() const
{
    return size_;
}


/*
* \brief push back funtion of ChunkyString
*
* \details adds the char c to the end of ChunkyString
*
* \param c  the char you pass to push back
*/ 
void ChunkyString::push_back(char c)
{
    if (size_ == 0)
    {
        Chunk newChunk = ChunkyString::Chunk(c);
        chunks_.push_back(newChunk);
    }
    else
    {
        Chunk& last = chunks_.back();
        if (last.length_ < Chunk::CHUNKSIZE)
        {    
            last.chars_[last.length_] = c;
            ++last.length_;
        }
        else if (last.length_ == Chunk::CHUNKSIZE)
        {
            Chunk newChunk = ChunkyString::Chunk(c);
            chunks_.push_back(newChunk);
        }
    }
    ++size_;
        
}


/*
* \brief operator== of ChunkyString
*
* \details checks if two ChunkyStrings have the same chars in the same order
*
*/ 
bool ChunkyString::operator==(const ChunkyString& rhs) const
{
    return (size() == rhs.size()) && equal(begin(), end(), rhs.begin());
}


/*
* \brief operator!= of ChunkyString
*
* \details checks if two ChunkyStrings do not have the same chars 
*          in the same order
*
*/ 
bool ChunkyString::operator!=(const ChunkyString& rhs) const
{
    return !(*this == rhs);
}


/*
* \brief print function of ChunkyString
*
* \details prints all chars in ChunkyString
*
*/ 
std::ostream& ChunkyString::print(std::ostream& out) const
{
    ConstIterator thisIter = cbegin();
    while (thisIter != cend())
    {
        out << *thisIter;
        ++thisIter;
    }
    return out;
}


/*
* \brief operator+= of ChunkyString
*
* \details adds the chars in rhs to the end of a Chunkysting 
*
*/ 
ChunkyString& ChunkyString::operator+=(const ChunkyString& rhs)
{
    const size_t startSize = rhs.size();
    if(startSize == 0)
    {
        return *this;
    }
    else
    {
        ConstIterator rhsIter = rhs.cbegin();
        for(size_t index = 0; index < startSize; ++index)
        {
            push_back(*rhsIter);
            ++rhsIter;
        }
        return *this;
    }       
}

/*
* \brief operator< of ChunkyString
*
* \details iterates through two ChunkStrings and compares the chars in them
*
*/ 
bool ChunkyString::operator<(const ChunkyString& rhs) const
{
    return lexicographical_compare(this->cbegin(), this->cend(), rhs.cbegin(),\
        rhs.cend(), char_traits<char>::lt);
}

/**
 * \brief 
 *
 * \details 
 *   helper function used in insert to move the element of 
 *      chars by one inorder to make space for the new char 
 *
 * \param  start a size_t that determines the index of the first index 
 *                 that needs to be moved down
 *         end   a size_t that determines the index of the last
 *                  index that needs to be moved down
 */
void ChunkyString::shiftDown(int start, int end, Chunk& chunk)
{
    for(int newIndex = start; newIndex >= end; --newIndex)
    {
        chunk.chars_[newIndex + 1] = chunk.chars_[newIndex];
    }
    
}

void ChunkyString::splitChunks(Chunk& newChunk, Chunk& currentChunk)
{
    int halfChunkSize = Chunk::CHUNKSIZE/2;
    int chunkSize = Chunk::CHUNKSIZE;
    for(int j = halfChunkSize; j < chunkSize; ++j)
    {
        newChunk.chars_[j-halfChunkSize] = currentChunk.chars_[j];
        ++newChunk.length_;
        --currentChunk.length_;
    }
}

/*
* \brief insert function of ChunkyString.
*
* \details inserts a given char after the iterator i
* \param  i iterator after which the char is supposed to be inserted
* \param  c char that we want to insert in the chunky string
* \return an iterator pointing to the new char we added
*/
ChunkyString::iterator ChunkyString::insert(iterator i, char c)
{
    int currentIndex = i.index_;
    int halfChunkSize = Chunk::CHUNKSIZE/2;
    int chunkSize = Chunk::CHUNKSIZE;
    int currentLen = i.chunk_->length_;
    Iterator::chunk_iter_t currentChunk = i.chunk_;
    Iterator::chunk_iter_t nextChunk = ++currentChunk;
    --currentChunk;
    
    if (currentLen == 0)
    {
        push_back(c);
    }
    else if (currentLen == chunkSize)
    {
        Chunk newChunk = Chunk(c);
        splitChunks(newChunk, *currentChunk);
        if(currentIndex > halfChunkSize)
        {
            shiftDown(newChunk.length_ - 1,
                currentIndex % halfChunkSize, newChunk);
        }
        else
        {
            shiftDown(currentChunk->length_ -1, 
                currentIndex, *currentChunk);
        }
        i.chunk_->chars_[currentIndex] = c;
        ++i.chunk_->length_;
        chunks_.insert(nextChunk, newChunk);
    }      
    else if (currentLen  < chunkSize)
    {
        shiftDown(currentChunk->length_ - 1, 
            currentIndex, *currentChunk);
        i.chunk_->chars_[currentIndex] = c;
        ++i.chunk_->length_;
    }
    ++size_;   
    return iterator(currentChunk, currentIndex);
}


/*
* \brief moveNexttoCurrent - helper function of ChunkyString.
*
* \details moves all chars after iterator i in this chunk 
*          over to the next chunk
* \param  i iterator at which we want to erase one char
* 
*/
void ChunkyString::moveNexttoCurrent(ChunkyString::Chunk& current, 
    ChunkyString::Chunk& next)
{
    for(size_t j = 0; j < next.length_; ++j)
    {
        current.chars_[current.length_ + j] = next.chars_[j];
    }
    current.length_+=next.length_;
}

/*
* \brief erase helper function of ChunkyString.
*
* \details deletes the contents at the slot iterator i is pointing at
* \param  i iterator at which we want to erase one char
* 
*/
void ChunkyString::eraseHelper(ChunkyString::iterator i)
{
    for (size_t newIndex = i.index_ + 1; 
        newIndex < i.chunk_->length_; ++newIndex)
    {
        i.chunk_->chars_[newIndex-1] = i.chunk_->chars_[newIndex];
    }
    --i.chunk_->length_;
}

/*
* \brief erase function of ChunkyString
*
* \details erases the char at a given iterator
* \param i  iterator that tells which spot we want to remove the char from
* \returns an iterator for the ChunkyString pointing to the char after i  
*
*/ 
ChunkyString::iterator ChunkyString::erase(iterator i)
{
    Iterator::chunk_iter_t currentChunk = i.chunk_;
    Iterator::chunk_iter_t nextChunk = ++currentChunk;
    --currentChunk;
    size_t currentIndex = i.index_;
    --size_;  
    if (currentChunk->length_ == 1)
    {
        return Iterator(chunks_.erase(currentChunk), 0);
    } 
    else
    {
        if(nextChunk->length_ + currentChunk->length_ > Chunk::CHUNKSIZE || 
            nextChunk == chunks_.end())
        {
            eraseHelper(i);
            return iterator(currentChunk, currentIndex);
        }
        else
        {
            eraseHelper(i);
            moveNexttoCurrent(*currentChunk, *nextChunk);
            chunks_.erase(nextChunk);
            return Iterator(currentChunk, currentIndex);
        }
    }   
}

/*
* \brief utilization function of ChunkyString
*
* \details  calculates and returns utilization by dividing the size of a string by
*           the number of Chunks * CHUNKSIZE
*
*/ 
double ChunkyString::utilization() const
{
    double chunksNum = 0; 
    std::list<Chunk>::const_iterator i = chunks_.begin();
    while(i != chunks_.end())
    {
        ++chunksNum;
        ++i;
    }
    return double(size_)/double(chunksNum * Chunk::CHUNKSIZE);
}