/**
 * \file noisytransmit.cpp
 * \author Fill me in!
 *
 * \brief Defines the noisyTransmit() function for stepping through a 
 * chunkystring and randomly doubling, erasing, or leaving each character
 * unchanged.
 *
 * \details
 *
 * \remarks
 *
 */

#include <stdexcept>
#include "chunkystring.hpp"
#include "noisy-transmission.hpp"

NoisyTransmission::NoisyTransmission(float errorRate)
    : errorRate_(errorRate), dis_(0, 1)
{
    seed();
}

void NoisyTransmission::seed()
{
    std::random_device rd;
    gen_.seed(rd());
}

float NoisyTransmission::getRandomFloat()
{
    return dis_(gen_);
}

void NoisyTransmission::transmit(ChunkyString& message)
{

    
    std::cout<<"before while loop"<<std::endl;
    for(ChunkyString::iterator iter = message.begin(); 
        iter != message.end(); ++iter)
    {
        float ourErrorRate = getRandomFloat();
        if (errorRate_ <= 0.5)
        {

            if(ourErrorRate <= errorRate_) //this is when we double 
            {
                
                message.insert(iter, *(iter));
            }
            else if(ourErrorRate <= 2 * errorRate_) //this is when we delete
            {
                
                message.erase(iter);
            }
        }

    }
}
