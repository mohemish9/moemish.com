# Overview
If you were to read up on `basic_string<char>` (which is the actual type\* for which `string` is a synonym), you would discover that the C++ standard is quite vague about the asymptotic complexity of various string operations. In particular, the complexity of the `insert` and `erase` operations are unspecified, but the documentation claims that these operations may be linear in the length of the string. 

This performance may not be sufficient for situations where `insert` and `erase` happen often. For example, a program that allows editing of character input (e.g., `nano`, `emacs` or `vim`) might need very efficient code to insert and delete characters in the middle of a string. Constant-time insertion and deletion are not possible if the string is represented using, for example, a primitive array of characters (even if the array is stored on the heap). Alternatively, a doubly-linked list of characters could have as much as 31 bytes of overhead for each 1-byte character, depending on the list's encoding and the computer architecture.

Your task over the next few assignments is to develop your own variant of `string` that can efficiently insert and remove characters anywhere in the string. This variant is called `ChunkyString`. The goal of this week's assignment is to understand what operations `ChunkyString` should support and how they should work. To do so, you will write **tests** and **pseudocode** for `ChunkyString`. In future assignments, you'll use the tests and pseudocode to help you implement `ChunkyString` in C++.

\* The <> brackets in `basic_string<char>` tell us it is a special kind of type called a _templated_ type. We'll talk more about this in class soon!

# Reading

In addition to reading this assignment, we strongly recommend the following resources:

* The C++ reference for [bidirectional iterators](http://www.cplusplus.com/reference/iterator/BidirectionalIterator/), as your ChunkyString iterator will support pre-increment and pre-decrement.

* _Code Complete_ Chapter 9, for writing good pseudocode (see Piazza Resources page for a PDF). Section 9.3, in particular, describes a good process for writing pseudocode (although you won't be writing any implementation code this week). The book recommends that pseudocode be in exclusively in English, but we are less dogmatic about that particular point, preferring to emphasize *clarity*. Your pseudocode should be clear and detailed enough that someone else in the class could implement your ideas without making any significant design decisions. As with all work, you should strive for elegance and clarity.  Helper "functions" are also appropriate when  writing pseudocode. Remember that pictures can be a great way to plan, and may (or even _should_) constitute a large portion of your pseudocode!

* _Code Complete_ Chapter 22, on testing (see Piazza Resources page for a PDF). This chapter has a lot of good tips, though not all of them are applicable to this assignment. The checklist on page 532 is an excellent place to start.


# Steps
There are 3 issues to complete for this assignment. We suggest that you budget your time for the issues as follows:

1. Read the specification and documentation (5% of your time). 

1. Write tests (50% of your time). 

1. Write pseudocode (45% of your time). 

Though a separate planning component is not strictly required, we **highly** recommend that you carefully plan `ChunkyString` operations on whiteboards or on paper before writing anything in your repository files. This will pay dividends in the coming weeks!

# Grading
Your submission will be graded as follows: 
* 20 points: correctness
* 10 points: completeness
* 5 points: style 
* 5 points: elegance
* 5 points: clarity 

See the [Grading Guidelines](https://cs.hmc.edu/cs70/wiki/Grading-Guidelines) wiki page for more information about what we're looking for in each of those categories. 

# A Final Note on the "Chunky String" Concept

Although it has evolved considerably over time, a "chunky string" assignment has existed in CS 70 for many years. It was first conceived by Prof. Kuenning, and it was he who named it "chunky string". This name is CS70-specific. (Dividing a sequence of items into a collection of fixed-size chunks isn't that unusual, but it does not seem to have a widely-used name.)
