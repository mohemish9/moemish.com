/**
 * \file stringtest.cpp
 *
 * \brief Tests a ChunkyString for correctness.
 */

#include "testing-logger.hpp"
#ifndef LOAD_GENERIC_STRING
/* This test code can be used two ways.  It can either test a local
 * ChunkyString implementation, or it can dynamically load an implementation
 * at runtime and test that.  In the first homework, you'll dynamically load an
 * implementation that someone else used, but in later assignments, you'll
 * set the value to zero to use your own.
 */
#define LOAD_GENERIC_STRING 1       // 0 = Normal, 1 = Load Code Dynamically
#endif

#if LOAD_GENERIC_STRING
#include "string-wrapper.hpp"       // Use dynamic loading magic!
using TestingString = GenericString;
#else
#include "chunkystring.hpp"         // Just include and link as normal.
using TestingString = ChunkyString;
#endif

#include <string>
#include <sstream>
#include <stdexcept>
#include <cstddef>
#include <cstdlib>
#include <cassert>

#include "signal.h"
#include "unistd.h"

using namespace std;

static const size_t TESTING_CHUNKSIZE = 12;     // Assuming a chunksize of 12

// Helper functions
/**
 * \brief Assuming chunks are supposed to be at least an average of 
 *        1/divisor full, checks for the lowest allowable utilization 
 *        for the input string
 *
 * \remarks A helper function for affirming a TestingString's utilization 
 *          is at least 1/divisor. E.g., to check for adherence to 1/2, 
 *          divisor would be 2. The function does so by calculating the 
 *          lowest allowable utilization for a string the length of the 
 *          input string, including handling the edge cases of small strings. 
 *          Since checkUtilization is not a test on its own, but rather
 *          a helper function to be used in other tests, it doesn't
 *          create its own TestingLogger object. Instead, its affirms
 *          will be associated with the TestingLogger of the calling
 *          function. 
 *
 * \param test          TestingString to check
 * \param divisor       Fullness of chunk = 1/divisor
 */
void checkUtilization(const TestingString& test, size_t divisor)
{
    double utilLimit = 0;

    if (test.size() > 0)
    {
        size_t chunks = 1;
        size_t size = test.size() - 1;
        divisor = TESTING_CHUNKSIZE / divisor;
        chunks += (size + divisor - 1) / divisor;
        utilLimit = double(size) / double(chunks * TESTING_CHUNKSIZE);
        affirm(test.utilization() > utilLimit);
    }
}



// Testing functions



bool TestingString_defaultConstructor_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString default constructor Test");
    TestingString s;
    affirm(s.size() == 0);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

bool TestingString_size_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString size Test");
    TestingString s;
    s.push_back('a');
    affirm(s.size() == 1);
    
    s.push_back('b');
    affirm(s.size() == 2);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

bool TestingString_operatornotequal_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString !=operator Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString s2;
    s2.push_back('a');
    affirm(s2 != s1);
    
    
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

bool TestingString_operatorequal_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString ==operator Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString s2;
    s2.push_back('a');
    s2.push_back('b');
    TestingString s3 = s1;

    affirm(s2 == s1);
    affirm(s2 == s3);
    
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

bool TestingString_operatorLessThan_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString operator< Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString s2;
    s2.push_back('a');
    TestingString s3 = s1;
    affirm(s2 < s1);
    affirm(s2 < s3);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

bool TestingString_utilization_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString utilization Test");
    TestingString s1;
    s1.push_back('u');
    checkUtilization(s1,2);

    TestingString s2;
    s2.push_back('a');
    s2.push_back('b');
    s2.push_back('c');
    s2.push_back('d');
    TestingString::iterator iter = s2.begin();
    ++iter;
    s2.erase(iter);
    checkUtilization(s2 , 4);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

bool TestingString_push_back_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString push_back Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString::iterator iter = s1.end();
    -- iter;
    affirm(*iter == 'b');
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

bool TestingString_insert_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString insert Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    s1.push_back('c');

    TestingString s2;
    s2.push_back('a');
    s2.push_back('c');

    TestingString::iterator iter = s2.begin();
    ++iter;

    TestingString::iterator iter2;  //iterator pointing to nothing
    iter2 = s2.insert(iter, 'b');
    affirm(s1 == s2);

    TestingString::iterator s2Begin = s2.begin();
    ++ s2Begin;
    affirm(iter2 == s2Begin);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

bool TestingString_erase_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString erase Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    s1.push_back('z');
    s1.push_back('c');
    TestingString s2;
    s2.push_back('a');
    s2.push_back('b');
    s2.push_back('c');

    TestingString::iterator iter = s1.end();
    -- iter;
    -- iter;
    TestingString::iterator iter2;  //iterator pointing to nothing
    iter2 = s1.erase(iter);
    affirm(s1 == s2);

    TestingString::iterator s1end = s1.end();
    -- s1end;
    affirm(s1end == iter2);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}


bool TestingString_addOperator_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString operator+= Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    s1.push_back('c');
    TestingString s2;
    s2.push_back('a');
    s2.push_back('b');
    TestingString s3;
    s3.push_back('c');

    s2 += s3;
    affirm(s1 == s2);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

bool TestingString_outPutStreamOperator_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString operator<< Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    s1.push_back('c');
    
    stringstream out;
    out << s1;
    affirm(out.str() == "abc");
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}


bool TestingString_begin_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString begin Test");
    TestingString s1;
    affirm(s1.begin() == s1.end());

    s1.push_back('a');
    s1.push_back('b');
    TestingString::iterator s1Begin = s1.begin();
    affirm(*s1Begin == 'a');
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

bool TestingString_end_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString end Test");
    TestingString s1;
    s1.push_back('b');
    s1.push_back('a');
    TestingString::iterator s1End = s1.end();
    -- s1End;
    affirm(*s1End == 'a');
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}


bool iterator_equal_notEqual_Operators_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("iterator ==operator and !=operator Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString::iterator s1Begin = s1.begin();
    TestingString::iterator s1End = s1.end();
    affirm(s1Begin == s1End);
    TestingString s2;
    TestingString::iterator s2Begin = s2.begin();
    TestingString::iterator s2End = s2.end();
    affirm(s2Begin == s2End);


    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

bool iterator_preincrement_predecrement_Operators_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("iterator ++operator and --operator Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString::iterator begin1 = s1.begin(); //iterator to begin
    TestingString::iterator begin2 = s1.begin(); //another iterator point to begin
    TestingString::iterator end = s1.end();
    ++begin1;
    affirm(begin1 != begin2);

    ++begin2;
    affirm(begin1 == begin2);

    --end;
    affirm(begin1 == end);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

bool iterator_dereference_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("iterator dereference Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString::iterator begin = s1.begin();
    affirm(*begin == 'a');
  
    TestingString::iterator end = s1.end();
    --end;
    affirm(*end == 'b');
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

//--------------------------------------------------
//           RUNNING THE TESTS
//--------------------------------------------------

// Called if the test runs too long.
static void timeout_handler(int)
{
    // We go super-low-level here, because we can't trust anything in
    // the C/C++ library to really be working right.
    write(STDERR_FILENO, "Timeout occurred!\n", 18);
    abort();
}

/// Run tests
int main(int argc, char** argv)
{
    // Initalize testing environment
    TestingLogger alltests{"All tests"};

#if LOAD_GENERIC_STRING
    // Load the desired string implementation, if that's what we're doing.

    if (argc != 2) {
        cerr << "Usage ./stringtest plugin" << endl;
        exit(0);
    }

    GenericString::loadImplementation(argv[1]);
#else
    // No setup to do if we're using ChunkyString directly
#endif
    
    signal(SIGALRM, timeout_handler);   // Call this when the timer expires
    alarm(10);                          // set the timer at 10 seconds

    // Add calls to your tests here...
    affirm(TestingString_defaultConstructor_Test());
    affirm(TestingString_size_Test());
    affirm(TestingString_operatornotequal_Test());
    affirm(TestingString_operatorequal_Test());
    affirm(TestingString_operatorLessThan_Test());
    affirm(TestingString_utilization_Test());
    affirm(TestingString_push_back_Test());
    affirm(TestingString_insert_Test());
    affirm(TestingString_erase_Test());
    affirm(TestingString_addOperator_Test());
    affirm(TestingString_outPutStreamOperator_Test());
    affirm(TestingString_begin_Test());
    affirm(TestingString_end_Test());
    affirm(iterator_equal_notEqual_Operators_Test());
    affirm(iterator_preincrement_predecrement_Operators_Test());
    affirm(iterator_dereference_Test());
    if (alltests.summarize(true)) {
        return 0;       // Error code of 0 == Success!
    } else {
        return 2;       // Arbitrarily chosen exit code of 2 means tests failed.
    }
}
