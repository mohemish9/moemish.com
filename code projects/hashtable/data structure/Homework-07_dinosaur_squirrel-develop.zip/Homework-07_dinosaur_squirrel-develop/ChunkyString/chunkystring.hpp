/**
 * \file chunkystring.hpp
 *
 * \authors CS 70 given code, with additions by ... your aliases here ...
 *
 * \brief Declares the ChunkyString class.
 */

#ifndef CHUNKYSTRING_HPP_INCLUDED
#define CHUNKYSTRING_HPP_INCLUDED 1

#include <cstddef>
#include <list>
#include <iostream>

/**
 * \class ChunkyString
 * \brief Efficiently represents strings where insert and erase are
 *    constant-time operations.
 *
 * \details This class is comparable to a linked-list of characters,
 *   but more space efficient.
 *
 */
class ChunkyString {
    // Forward declarations of Iterator
    class Iterator;

public:

    using iterator = Iterator;

    /**
     * \brief Default constructor
     *
     * \note constant time
     */
    ChunkyString();

    /// Return an iterator to the first character in the ChunkyString.
    iterator begin();

    /// Return an iterator to "one past the end"
    iterator end();

    /**
     * \brief Inserts a character at the end of the ChunkyString.
     *
     * \param c     Character to insert
     * 
     * \note constant time
     */
    void push_back(char c);

    // Standard string ops: size, concatenation, (in)equality, comparison, print
    size_t size() const;  ///< String size \note constant time
    ChunkyString& operator+=(const ChunkyString& rhs); ///< String concatenation
    bool operator==(const ChunkyString& rhs) const;    ///< String equality
    bool operator!=(const ChunkyString& rhs) const;    ///< String inequality
    std::ostream& print(std::ostream& out) const;      ///< String printing

    /**
     * \brief String comparison
     *
     * \remarks String comparison is lexicographic, which means:
     *    + Two strings `s1` and `s2` are compared character by character.
     *    + The first characters that aren't equal determine the order. If the
     *      character value from `s1` is smaller than the corresponding one from
     *      `s2`, then `s1` < `s2`, and vice-versa.
     *    + If `s1` is a prefix of `s2`, then `s1` < `s2`, and vice-versa.
     *    + If `s1` and `s2` have exactly the same character, then neither is
     *      less than the other.
     *    + An empty string is less than any other string, except the empty
     *      string.
     * \see http://www.cplusplus.com/reference/string/string/compare/
     * \see http://en.cppreference.com/w/cpp/algorithm/lexicographical_compare
     */
    bool operator<(const ChunkyString& rhs) const;
    

    /**
     * \brief Insert a character before the character at i.
     * \details
     *   What makes ChunkyString special is its ability to insert and
     *   erase characters quickly while remaining space efficient.
     *
     * \param i     iterator to specify insertion point
     * \param c     character to insert
     *
     * \returns an iterator pointing to the newly inserted character.
     *
     * \note constant time
     *
     * \warning invalidates all iterators except the returned iterator
     */
    iterator insert(iterator i, char c);

    /**
     * \brief Erase a character at i
     * \details
     *   What makes ChunkyString special is its ability to insert and
     *   erase characters quickly while remaining space efficient.
     *
     * \param i     iterator pointing to the character to erase
     *
     * \returns an iterator pointing to the character after the one
     *   that was deleted.
     *
     * \note constant time
     *
     * \warning invalidates all iterators except the returned iterator
     *
     * \warning erasing from an empty string is undefined behavior
     */
    iterator erase(iterator i);

    /**
     * \brief Average capacity of each chunk, as a fraction
     *
     * \details 
     *   This function computes the fraction of the ChunkyString's character
     *   cells that are in use. It is defined as 
     *
     *   \f[\frac{\mbox{number of characters in the string}}
     *           {\mbox{number of chunks}\times\mbox{CHUNKSIZE}}  \f] 
     *   
     *   For reasonably sized strings (i.e., those with more than one or two 
     *   characters), utilization should never fall to near one character per 
     *   chunk; otherwise the data structure would be wasting too much space.
     *
     *   The utilization for an empty string is undefined (i.e., any value is
     *   acceptable).
     * 
     * \note constant time
     */
    double utilization() const;

private:    

    // NOTE: You can choose to change Chunk to be a class rather than a struct
    /**
     * \struct Chunk
     * \brief Holds part of a ChunkyString
     */
    struct Chunk {
        /**
         * \brief Maximum size of a chunk
         *
         * \remarks Although we set the value of CHUNKSIZE here to be 12,
         *          that's an implementation detail. We're allowed to change 
         *          it, and user's code (as well as our own implementation code)
         *          shouldn't depend on CHUNKSIZE having a particular value.
         */
        static const size_t CHUNKSIZE = 12;
        size_t length_;          ///< Number of characters occupying this chunk
        char chars_[CHUNKSIZE];  ///< Contents of this chunk
    };

    /**
     * \class Iterator
     * \brief Iterator for ChunkyString.
     */
    class Iterator {
    public:
        
        /// Default constructor, to be STL-compliant
        Iterator();

        // Operations
        Iterator& operator++();
        Iterator& operator--();
        char& operator*() const;
        bool operator==(const Iterator& rhs) const;
        bool operator!=(const Iterator& rhs) const;

    private:
        // NOTE: Data members have not yet been implemented. You get to decide
        //       how to encode the iterator 
    };

    // ChunkyString data members
    size_t size_;             ///< Length of the string
    std::list<Chunk> chunks_; ///< Linked list of chunks
    
};

#endif // CHUNKYSTRING_HPP_INCLUDED
