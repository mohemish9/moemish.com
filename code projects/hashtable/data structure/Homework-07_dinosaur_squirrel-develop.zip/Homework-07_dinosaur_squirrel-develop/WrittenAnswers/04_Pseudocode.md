## ChunkyString Pseudocode

### `ChunkyString::Iterator` Encoding
  void ChunkyString::Iterator()
  {
    Define and initialize an iterator that iterates over the list of chunks (chunkIndex_)
    Define and initialize an integer holding the index of the char the iterator is pointing to inside the chunk (charIndex_)

  }
    
### `ChunkyString::Iterator` Operations

#### `operator*()`

```
    char ChunkyString::Iterator operator*()
    {
        returns the value of the char of the index charIndex_ held in the chunk the chunkIndex_ iterator is storing.
    }

```


#### `operator==(rhs)`

```
    bool ChunkyString::Iterator operator==(rhs)
    {
        if the value of chunkIndex_ and charIndex_ is the same in both iterators (this and rhs)
            return true
        otherwise
            return false
    }
```


#### `operator++()`

```
    bool ChunkyString::Iterator operator++()
    {
        if charIndex_ is less than the chunk length_
            increment charIndex_ by one
        otherwise, if charIndex eqaul to the chunk length_
            set chunkIndex_ to the next chunk
            set charIndex_ to zero
    }
```


#### `operator--()`

```
    bool ChunkyString::Iterator operator--()
    {
        if charIndex_ is larger than zero 
            decrement charIndex_ by one
        otherwise, if is zero
            set chunkIndex_ to the previous chunk
            set charIndex_ to the length of the chunk in chunkIndex
    }
```

### Empty `ChunkyString`

    It has a size_t (size_) holding the value 0
    It has an empty list of chunks (chunks_) 

### `ChunkyString` Operations

#### `iterator begin()`

```
    iterator ChunkyString::begin()
    {
        call the default constructor void ChunkyString::Iterator()  to create an empty iterator
        set the value of chunkIndex_ to the first chunk in the list chunks_
        set the value charIndex to zero
        return the iterator 
    }
```


#### `iterator end()`

```
    iterator ChunkyString::end()
    {
        call the default constructor void ChunkyString::Iterator()  to create an empty iterator
        set the value of chunkindex_ to the last chunk in the list chunks_
        set the value charIndex to the length of the chunk in chunkIndex_
        increment the iterator
        returns the iterator 
    }
```


#### `operator==(rhs)`

```
    bool ChunkyString::operator==(rhs)
    {
        Define and initialize an iterator (thisIter) equal to this.begin()
        Define and initialize an iterator (rhsIter) equal to rhs.begin()
        while both thisIter is not equal to this.end() and rhsIter is not equal to rhs.end()
            if the value of dereferencing thisIter is equal to the value of defereferencing rhsIter
                increment thisIter and rhsIter
                rerun the loop
            otherwise
                return false
        if loop ended return true
    }
```


#### `operator<(rhs)`

```
    bool ChunkyString::operator<(rhs)
    {
        Define and initialize an iterator (thisIter) equal to this.begin()
        Define and initialize an iterator (rhsIter) equal to rhs.begin()
        while both thisIter is not equal to this.end() and rhsIter is not equal to rhs.end()
            if the value of dereferencing thisIter is less than the value of defereferencing rhsIter
                increment thisIter and rhsIter
                rerun the loop
            otherwise
                return false
        if loop ended return true
    }
```


#### `push_back(char c)`

```
     void ChunkyString::push_back(char c)
    {
        Define and initialize an iterator (iter) equal to this.end()
        decrement iter 
        if iter is pointing to a chunk that has space in it (*iter is empty)
            while iter is empty
                decrement iter 
            incerment iter once (so that it is the pointing to the char after the last one)
            set this char to c
        otherwise
            create a new chunk
            add the new chunk to chunks_
            set the value of the first char in the new chunk to c
        
    }
```


#### `operator+=(rhs)`

```
     ChunkyString ChunkyString::operator+=(rhs)
    {
        Define and initialize an iterator (rhsIter) equal to rhs.begin()
        Define and initialize an iterator (rhsEnd) equal to rhs.end()
        while rhsIter is not equal rhsEnd
            push_back( value of * rhsIter )
        
    }
```



#### `insert(char c, iterator i)`

```
    iterator ChunkyString::insert(char c, iterator i)
    {
        if the last element in the chunkIndex_ value stored in i is full
            if the next chunk contains a free slot
                move the last element in the chunk pointed to by chunkIndex_ to the next chunk
                move all the elements in the chunk pointed to by chunkIndex_ down the array by one
                set the value of the slot i is pointing to equal to c
            otherwise
                create a new chunk and make it the next chunk after the chunk pointed to by chunkIndex_
                move half of the elements in the chunk pointed to by chunkIndex_ to the new chunk
                move the rest of elements in the chunk pointed to by chunkIndex_ down the array by one
                set the value of the slot i is pointing to equal to c
        otherwise
            move the rest of elements in the chunk pointed to by chunkIndex_ down the array by one
            set the value of the slot i is pointing to equal to c
        return an iterator pointing to the slot we edited
    }
```


#### `erase(iterator i)`

```
    iterator ChunkyString::erase(iterator i)
    {
        if chunk only contains one char
            delete chunk
        otherwise, if chunk contains 1/4 of its capacity
            if the next chunk does not have enough room
                move a part of the elements in the next chunk to the chunk i is pointing to
                delete the contents of the slot i is pointing to
            otherwise  
                move the elements in the current chunk to the next one
                delete the contents of the slot i is pointing to
        otherwise
            delete the contents of the slot i is pointing to
            move any non-empty elements in the same chunk after the slot i is pointing to up by one
    }
```

