Planning diagrams should be uploaded in this directory.

Here's an example for what they might look like (see Issue #2): 

![Issue 2 example diagram](https://github.com/hmc-cs70-fall2018/Materials/blob/master/assets/intlist/Issue_2.jpg)
