#ifndef LOOPS_HPP_INCLUDED
#define LOOPS_HPP_INCLUDED

unsigned int loopA(unsigned int N);

unsigned int loopB(unsigned int N);

unsigned int loopC(unsigned int N);

unsigned int loopD(unsigned int N);

unsigned int loopE(unsigned int N);

#endif
