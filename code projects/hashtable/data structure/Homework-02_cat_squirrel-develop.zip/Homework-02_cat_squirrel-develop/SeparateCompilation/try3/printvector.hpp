#include <vector>

#ifndef PRINTVECTOR_INCLUDED
#define PRINTVECTOR_INCLUDED

void printVector(std::vector<int> v);

#endif
