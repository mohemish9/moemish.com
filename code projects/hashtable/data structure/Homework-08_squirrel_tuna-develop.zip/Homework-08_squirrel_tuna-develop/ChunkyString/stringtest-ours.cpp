/**
 * \file stringtest-ours.cpp
 * \author: hmc-tuna-f18 and hmc-squirrel-f18
 * \brief Testing a ChunkyString for correctness.
 */

#include "testing-logger.hpp"


#ifndef LOAD_GENERIC_STRING
/* This test code can be used two ways.  It can either test a local
 * ChunkyString implementation, or it can dynamically load an implementation
 * at runtime and test that.  In the first homework, you'll dynamically load an
 * implementation that someone else used, but in later assignments, you'll
 * set the value to zero to use your own.
 */
#define LOAD_GENERIC_STRING 0       // 0 = Normal, 1 = Load Code Dynamically
#endif

#if LOAD_GENERIC_STRING
#include "string-wrapper.hpp"       // Use dynamic loading magic!
using TestingString = GenericString;
#else
#include "chunkystring.hpp"         // Just include and link as normal.
using TestingString = ChunkyString;
#endif

#include <string>
#include <sstream>
#include <stdexcept>
#include <cstddef>
#include <cstdlib>
#include <cassert>

#include "signal.h"
#include "unistd.h"

using namespace std;

static const size_t TESTING_CHUNKSIZE = 12;     // Assuming a chunksize of 12

/******************************************************************************
 * Helper functions
 *****************************************************************************/
/**
 * \brief Assuming chunks are supposed to be at least an average of 
 *        1/divisor full, checks for the lowest allowable utilization 
 *        for the input string
 *
 * \remarks A helper function for affirming a TestingString's utilization 
 *          is at least 1/divisor. E.g., to check for adherence to 1/2, 
 *          divisor would be 2. The function does so by calculating the 
 *          lowest allowable utilization for a string the length of the 
 *          input string, including handling the edge cases of small strings. 
 *          Since checkUtilization is not a test on its own, but rather
 *          a helper function to be used in other tests, it doesn't
 *          create its own TestingLogger object. Instead, its affirms
 *          will be associated with the TestingLogger of the calling
 *          function. 
 *
 * \param test          TestingString to check
 * \param divisor       Fullness of chunk = 1/divisor
 */
void checkUtilization(const TestingString& test, size_t divisor)
{
    double utilLimit = 0;

    if (test.size() > 0)
    {
        size_t chunks = 1;
        size_t size = test.size() - 1;
        divisor = TESTING_CHUNKSIZE / divisor;
        chunks += (size + divisor - 1) / divisor;
        utilLimit = double(size) / double(chunks * TESTING_CHUNKSIZE);
        affirm(test.utilization() >= utilLimit);
    }
}


/**
 * \brief Tests that the default constructor works 
 */
bool TestingString_Constructor_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString default constructor Test");
    TestingString s;
    affirm(s.size() == 0);
    TestingString d = TestingString(s);
    affirm(d == s);
    affirm(d.size() == 0);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the size() function 
 * \remarks Tests that the size data member adjusts properly when we 
 *          use push_back
 */
bool TestingString_size_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString size Test");
    TestingString s;
    s.push_back('a');
    affirm(s.size() == 1);
    
    s.push_back('b');
    affirm(s.size() == 2);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the operator!= function 
 * \remarks Tests that operator != works by comparing two different
 *          ChunkyStrings
 */
bool TestingString_operatornotequal_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString !=operator Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString s2;
    s2.push_back('a');
    affirm(s2 != s1);
    
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the operator == function 
 * \remarks Tests that operator == works by comparing two 
 *          ChunkyStrings and checking that they hold the same chars
 */
bool TestingString_operatorequal_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString ==operator Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString s2;
    s2.push_back('a');
    s2.push_back('b');
    TestingString s3 = s1;

    affirm(s2 == s1);
    affirm(s2 == s3);
    
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the operator< function 
 * \remarks Tests that operator < works by comparing two different
 *          ChunkyStrings
 */
bool TestingString_operatorLessThan_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString operator< Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString s2;
    s2.push_back('c');

    affirm(s1 < s2);
    
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the checkUtilization function 
 * \remarks Tests that utilization functions the way we want it to
 *          by using checkUtilization on ChunkyStrings
 */
bool TestingString_utilization_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString utilization Test");
    TestingString s1;
    s1.push_back('u');
    checkUtilization(s1,2);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the push_back function 
 * \remarks Tests that push_back works by calling it on 
 *          ChunkyStrings and then using an iterator to check
 *          that chars are added correctly
 */
bool TestingString_push_back_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString push_back Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString::iterator iter = s1.end();
    --iter;
    affirm(*iter == 'b');
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the insert function 
 * \remarks Tests that insert works by using iterators to make sure
 *          chars are appearing in the correct location 
 */
bool TestingString_insert_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString insert Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    s1.push_back('c');

    TestingString s2;
    s2.push_back('a');
    s2.push_back('c');

    TestingString::iterator iter = s2.begin();
    ++iter;

    TestingString::iterator iter2;  //iterator pointing to nothing
    iter2 = s2.insert(iter, 'b');
    affirm(s1 == s2);

    TestingString::iterator s2Begin = s2.begin();
    ++ s2Begin;
    affirm(iter2 == s2Begin);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the erase function 
 * \remarks Tests that erase works by calling it on 
 *          ChunkyStrings then using iterators to check 
 */
bool TestingString_erase_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString erase Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    s1.push_back('z');
    s1.push_back('c');
    TestingString s2;
    s2.push_back('a');
    s2.push_back('b');
    s2.push_back('c');

    TestingString::iterator iter = s1.end();
    -- iter;
    -- iter;
    TestingString::iterator iter2;  //iterator pointing to nothing
    iter2 = s1.erase(iter);
    affirm(s1 == s2);

    TestingString::iterator s1end = s1.end();
    -- s1end;
    affirm(s1end == iter2);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the operator+= function 
 * \remarks Tests that operator += works by adding two different
 *          ChunkyStrings and comparing it to a string that looks
 *          the same 
 */
bool TestingString_addOperator_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString operator+= Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    s1.push_back('c');
    TestingString s2;
    s2.push_back('a');
    s2.push_back('b');
    TestingString s3;
    s3.push_back('c');

    s2 += s3;
    affirm(s1 == s2);

    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}


/**
 * \brief Testing the begin() function
 */
bool TestingString_begin_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString begin Test");
    TestingString s1;
    affirm(s1.begin() == s1.end());

    s1.push_back('a');
    s1.push_back('b');
    TestingString::iterator s1Begin = s1.begin();
    affirm(*s1Begin == 'a');
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the end function
 */
bool TestingString_end_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("TestingString end Test");
    TestingString s1;
    s1.push_back('b');
    s1.push_back('a');
    TestingString::iterator s1End = s1.end();
    -- s1End;
    affirm(*s1End == 'a');
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the iterator operator == and != functions
 */
bool iterator_equal_notEqual_Operators_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("iterator ==operator and !=operator Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString::iterator s1Begin = s1.begin();
    TestingString::iterator s1End = s1.end();
    affirm(s1Begin != s1End);
    TestingString s2;
    TestingString::iterator s2Begin = s2.begin();
    TestingString::iterator s2End = s2.end();
    affirm(s2Begin == s2End);


    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the iterator operator ++ and -- functions
 */
bool iterator_preincrement_predecrement_Operators_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("iterator ++operator and --operator Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString::iterator begin1 = s1.begin(); //iterator to begin
    TestingString::iterator begin2 = s1.begin(); //another iterator point to begin
    TestingString::iterator end = s1.end();
    ++begin1;
    affirm(begin1 != begin2);

    ++begin2;
    affirm(begin1 == begin2);

    --end;
    affirm(begin1 == end);
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the iterator operator* (dereference) function
 */
bool iterator_dereference_Test()
{
    // Set up the TestingLogger object
    TestingLogger log("iterator dereference Test");
    TestingString s1;
    s1.push_back('a');
    s1.push_back('b');
    TestingString::iterator begin = s1.begin();
    affirm(*begin == 'a');
  
    TestingString::iterator end = s1.end();
    --end;
    affirm(*end == 'b');
    // Print a summary of the all the affirmations and return true
    // if they were all successful.
    return log.summarize();
}

/**
 * \brief Testing the string by inserting at the back of a 
 *        ChunkyString and then leveraging size() and iterators to check     
 */
bool insertAtBackTest()
{
    TestingLogger log("insertAtBack test");
    TestingString ourString;
    affirm(ourString.size() == 0); //checking if ourString is empty
    TestingString::iterator ourIterator;
    ourString.push_back('c');
    ourString.push_back('a');
    ourIterator = --ourString.end();
    ourString.insert(ourIterator, 'd');
    affirm(ourString.size() == 3); // checking if the size of out string is 3 after adding 3 characters
    TestingString::iterator secondIt = ++ourString.begin();
    affirm(*secondIt == 'd');
    TestingString::iterator thirdIt = ourString.end();
    ourString.insert(thirdIt, 'e');
    affirm(ourString.size() == 4); 
    checkUtilization(ourString, 2); // when we are inserting, check to see if at least half the chunk is being used
    return log.summarize();
}

/**
 * \brief Testing the string by inserting at the beginning of a 
 *        ChunkyString and then leveraging size() and iterators to check     
 */
bool insertAtFrontTest() 
{
    TestingLogger log("insertAtFront test");
    TestingString ourString;
    affirm(ourString.size() == 0); //check size of string
    ourString.push_back('a'); 
    TestingString::iterator ourIterator = ourString.begin();
    ourString.insert(ourIterator, 'c'); //insert using insert function
    affirm(ourString.size() == 2);
    checkUtilization(ourString, 2); //check that at least half of chunk is being used
    TestingString::iterator secondIt = ourString.begin();
    affirm(*secondIt ==  'c');  //second iterator checks that the order has changed after insert
    return log.summarize();
}

/**
 * \brief Testing the string by inserting randomly in a ChunkyString
 *        ChunkyString and then leveraging size() and iterators to check     
 */
bool insertAtRandomTest() 
{
    TestingLogger log("insertAtRandom test");
    TestingString ourString;
    affirm(ourString.size() == 0);
    ourString.push_back('a');
    ourString.push_back('d'); 
    ourString.push_back('e');
    ourString.push_back('f'); 
    ourString.push_back('g');
    ourString.push_back('h');
    TestingString::iterator ourIterator = ourString.end();
    --ourIterator;
    --ourIterator; //decrementing iterator so we start in a "random" location in ourString
    ourString.insert(ourIterator, 'c'); //insert c after f and before g 
    affirm(ourString.size() == 7);
    checkUtilization(ourString, 2);
    TestingString::iterator thirdIt = ourString.end();
    --thirdIt;
    --thirdIt;
    --thirdIt;
    affirm(*thirdIt == 'c');  //checking that 'c' was inserted 
    return log.summarize();
}

/**
 * \brief Testing the string by erasing at the back of a 
 *        ChunkyString and then leveraging size() and iterators to check     
 */
bool eraseBackTest()
{
    TestingLogger log("eraseBack test");
    TestingString ourString; 
    affirm(ourString.size() == 0);
    ourString.push_back('a');
    ourString.push_back('d'); 
    ourString.push_back('e');
    affirm(ourString.size() == 3);
    TestingString::iterator ourIterator = --ourString.end(); //creating iterator
    ourString.erase(ourIterator); // calling function on iterator so delete it
    affirm(ourString.size() == 2);
    checkUtilization(ourString, 4);
    TestingString::iterator secondit = --ourString.end();
    affirm(*secondit == 'd'); //check that 'd' is now the end of the string 
    return log.summarize();

}

/**
 * \brief Testing the string by erasing at the front of a 
 *        ChunkyString and then leveraging size() and iterators to check     
 */
bool eraseFrontTest() 
{
    TestingLogger log("eraseFront test");
    TestingString ourString;
    affirm(ourString.size() == 0);
    ourString.push_back('a');
    ourString.push_back('d'); 
    ourString.push_back('e');
    affirm(ourString.size() == 3);
    TestingString::iterator ourIterator = ourString.begin();
    ourString.erase(ourIterator); // calling function on iterator so delete it
    affirm(ourString.size() == 2);
    checkUtilization(ourString, 4);
    TestingString::iterator secondIt = ourString.begin();
    affirm(*secondIt == 'd'); //checks that 'd' is the new beginning of the string 
    return log.summarize();
}

/**
 * \brief Testing the string by erasing randomly in a 
 *        ChunkyString and then leveraging size() and iterators to check     
 */
bool eraseRandomTest() 
{
    TestingLogger log("eraseFront test");
    TestingString ourString;
    affirm(ourString.size() == 0);
    ourString.push_back('a');
    ourString.push_back('d'); 
    ourString.push_back('e');
    ourString.push_back('h'); 
    ourString.push_back('j');
    affirm(ourString.size() == 5);
    checkUtilization(ourString, 4);
    TestingString::iterator ourIterator = ourString.begin();
    ++ourIterator;
    ++ourIterator;
    ++ourIterator;
    ourString.erase(ourIterator); //erasing "h"
    TestingString::iterator secondIt = ourString.begin();
    ++secondIt;
    ++secondIt;
    ++secondIt; 
    affirm(*secondIt == 'j'); //checking that 'j' is at the old location of 'h'
    return log.summarize();
}

/**
 * \brief   more rigorous erase tests
 * \remark  uses for loops to erase a lot of characters in the middle of a string    
 */
bool eraseTest2()
{
    TestingLogger log("more erase tests");
    TestingString ourString;
    affirm(ourString.size() == 0);
    for (int i = 0; i < 14; ++i){
        ourString.push_back('a');
    }
    for (int j = 0; j < 5; ++j){
        TestingString::iterator ourIterator = ourString.end();
        for (int n = 0; n < 4; ++n){
            --ourIterator;
        }
        ourString.erase(ourIterator);
        checkUtilization(ourString, 4);
    }

    affirm(ourString.size() == 9);
    return log.summarize();
}

/**
 * \brief   more rigorous insert tests
 * \remark  uses for loops to insert a lot of characters in the middle of a string    
 */
bool insertTest2()
{
    TestingLogger log("more insert tests");
    TestingString ourString;
    affirm(ourString.size() == 0);
    for (int i = 0; i < 18; ++i){ //adding 'g' to ourString 18 times 
        ourString.push_back('g');
    }

    for (int j = 0; j < 6; ++j){  //inserting 'c' 6 times 
        TestingString::iterator ourIterator = ourString.end();
        for (int n = 0; n < 5; ++n){
            --ourIterator; //decrementing our iterator every time so we insert at a "random" location
        }
        ourString.insert(ourIterator, 'c');
        checkUtilization(ourString, 2); 
    }
    affirm(ourString.size() == 24);
    return log.summarize();

}

bool eraseTest3()
{
    TestingLogger log("more erase tests!!");
    TestingString ourString;
    affirm(ourString.size() == 0);
    for (int i = 0; i < 20; ++i){ //adding 'a' to ourString 20 times 
        ourString.push_back('a');
    }
    for (int j = 0; j < 3; ++j){  //erasing 3 chars
        TestingString::iterator ourIterator = ourString.end();
        for (int n = 0; n < 4; ++n){ //decrement iterator to take us to a "random" location in ourString
            --ourIterator;
        }
        ourString.erase(ourIterator);
        checkUtilization(ourString, 4); //checks that at least 1/4 of string is being used (b/c both insert and erase are being used)
    }

    affirm(ourString.size() == 17); //checks size after erases

    for (int n = 0; n < 6; ++n){  //inserting 6 chars
        TestingString::iterator ourIterator2 = ourString.end();
        for (int x = 0; x < 3; ++x){
            --ourIterator2; //decrement iterator so we can get to a "random" spot in the string 
        }
        ourString.insert(ourIterator2, 'c'); 
        checkUtilization(ourString, 2); 
    }

    affirm(ourString.size() == 23);
    return log.summarize();
}

bool bigTest()
{
    TestingLogger log("huge chunk delete!");
    TestingString ourString;
    affirm(ourString.size() == 0);
    for (int i = 0; i < 5000; ++i){ //adding 5000 chars to ourstring
        ourString.push_back('a');
    }
    for (int j = 0; j < 3000; ++ j) { //erasing 3000 chars
        TestingString::iterator ourIterator = ourString.end();
        for (int n = 0; n < 2500; ++n){ //decrementing 2500 times takes us to roughly middle of the string to perform erase
            --ourIterator; 
        }
        ourString.erase(ourIterator);
        checkUtilization(ourString, 4);
    }
    return log.summarize();
}

/**
 * \brief   Testing that string size and erase work properly by erasing to make a string empty
 */
bool emptyTest()
{
    TestingLogger log("check empty");
    TestingString emptyString;
    TestingString otherString;
    affirm(emptyString.size() == 0);
    affirm(otherString.size() == 0);
    for (int i = 0; i < 3; ++i){ //adding 3 chars to otherString
        otherString.push_back('a');
        checkUtilization(otherString, 2);
    }
    for (int j = 0; j < 3; ++j){  //erasing all chars in otherString
        TestingString::iterator ourIterator = otherString.begin();
        otherString.erase(ourIterator);
        checkUtilization(otherString, 4); //erase is performed so we check to make sure 1/4 of the space is being used 
    }

    affirm(emptyString == otherString); //checks that otherString is empty again
    affirm(otherString.size() == 0); 
    return log.summarize();
}


//--------------------------------------------------
//           RUNNING THE TESTS
//--------------------------------------------------

// Called if the test runs too long.
static void timeout_handler(int)
{
    // We go super-low-level here, because we can't trust anything in
    // the C/C++ library to really be working right.
    write(STDERR_FILENO, "Timeout occurred!\n", 18);
    abort();
}

/// Run tests
int main(int argc, char** argv)
{
    // Initalize testing environment
    TestingLogger alltests{"All tests"};

#if LOAD_GENERIC_STRING
    // Load the desired string implementation, if that's what we're doing.

    if (argc != 2) {
        cerr << "Usage ./stringtest plugin" << endl;
        exit(0);
    }

    GenericString::loadImplementation(argv[1]);
#else
    // No setup to do if we're using ChunkyString directly
#endif
    
    signal(SIGALRM, timeout_handler);   // Call this when the timer expires
    alarm(10);                          // set the timer at 10 seconds

    // Add calls to your tests here...
    affirm(TestingString_Constructor_Test());
    affirm(TestingString_size_Test());
    affirm(TestingString_operatornotequal_Test());
    affirm(TestingString_operatorequal_Test());
    affirm(TestingString_operatorLessThan_Test());
    affirm(TestingString_utilization_Test());
    affirm(TestingString_push_back_Test());
   // affirm(TestingString_insert_Test());
    //affirm(TestingString_erase_Test());
    affirm(TestingString_addOperator_Test());
    affirm(TestingString_begin_Test());
    affirm(TestingString_end_Test());
    affirm(iterator_equal_notEqual_Operators_Test());
    affirm(iterator_preincrement_predecrement_Operators_Test());
    affirm(iterator_dereference_Test());


   /* affirm(insertAtBackTest());
    affirm(insertAtFrontTest());
    affirm(insertAtRandomTest());
    affirm(eraseBackTest());
    affirm(eraseFrontTest());
    affirm(eraseRandomTest());
    affirm(eraseTest2());
    affirm(eraseTest3());
    affirm(bigTest());
    affirm(emptyTest());
*/
    if (alltests.summarize(true)) {
        return 0;       // Error code of 0 == Success!
    } else {
        return 2;       // Arbitrarily chosen exit code of 2 means tests failed.
    }
}