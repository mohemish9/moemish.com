/*
 * \file chunkystring.cpp
 * \authors hmc-tuna-f18 and hmc-squirrel-f18
 * \brief Implemenation of chunkystring and its private classes.
*/

#include "chunkystring.hpp"
#include "testing-logger.hpp"
#include <list>
#include <algorithm>

using namespace std;

/*
* \brief Default constructor for a ChunkyString
* \details the chunkystring should have a size of 0 and
* chunks_ is already initialized in the header file
*/
ChunkyString::ChunkyString()
 : size_(0)
{
 
}


ChunkyString::ChunkyString(const ChunkyString& rhs)
 : size_(rhs.size_),
   chunks_(rhs.chunks_)
{
 
}
/*
* \brief Default constructor for a Chunk, a struct of ChunkyString.
*
* \details the chunk is initialized with one character
* 
*/
ChunkyString::Chunk::Chunk(char first)
 : length_(1)
{
    chars_[0] = first;
}

/*
* \brief begin function of chunkystring
*
* \returns an iterator pointing to the first spot in the chunk
*/
ChunkyString::iterator ChunkyString::begin()
{
    return iterator(chunks_.begin(), 0);;
}

/*
* \brief end function of chunkystring
*
* \returns an iterator pointing to the spot after the last one
*/
ChunkyString::iterator ChunkyString::end()
{
   
    return iterator(chunks_.end(), 0);
}

/*
* \brief cbegin function of chunkystring
*
* \returns a Constant iterator pointing to the first spot
*/
ChunkyString::const_iterator ChunkyString::cbegin() const
{
    ConstIterator i = ChunkyString::ConstIterator();
    i.chunk_ = chunks_.begin();
    i.index_ = 0;
    return i;
}

/*
* \brief cend function of chunkystring
*
* \returns an constant iterator pointing to the spot after the last one
*/ 
ChunkyString::const_iterator ChunkyString::cend() const
{
    ConstIterator i = ChunkyString::ConstIterator();
    i.chunk_ = chunks_.end();
    i.index_ = 0;
    return i;
}

/*
* \brief size funtion of ChunkyString
*
* \returns number of chars in the chunky string
*/ 
size_t ChunkyString::size() const
{
    return size_;
}

/*
* \brief push back funtion of ChunkyString
*
* \details adds the char c to the end of ChunkyString
*
* \param c  the char you pass to push back
*/ 
void ChunkyString::push_back(char c)
{
    if (size_ == 0)
    {
        Chunk newChunk = ChunkyString::Chunk(c);
        chunks_.push_back(newChunk);
    }
    else
    {
        Chunk& last = chunks_.back();
        if (last.length_ < Chunk::CHUNKSIZE)
        {    
            last.chars_[last.length_] = c;
            ++last.length_;
        }
        else if (last.length_ == Chunk::CHUNKSIZE)
        {
            Chunk newChunk = ChunkyString::Chunk(c);
            size_t move = (1/2)* Chunk::CHUNKSIZE;
            newChunk.chars_[move] = c;
            for(size_t i= 0; i < move; ++i)
            {
                newChunk.chars_[i] = last.chars_[i + move];
                ++newChunk.length_;
                --last.length_;
            } 
            chunks_.push_back(newChunk);
        }
    }
    ++size_;
        
}

/*
* \brief operator== of ChunkyString
*
* \details checks if two ChunkyStrings have the same chars in the same order
*
*/ 
bool ChunkyString::operator==(const ChunkyString& rhs) const
{
    return (size() == rhs.size()) && equal(begin(), end(), rhs.begin());
}

/*
* \brief operator!= of ChunkyString
*
* \details checks if two ChunkyStrings do not have the same chars in the same order
*
*/ 
bool ChunkyString::operator!=(const ChunkyString& rhs) const
{
    if(*this == rhs)
    {
        return false;
    }
    else
    {
        return true;
    }
}

/*
* \brief print function of ChunkyString
*
* \details prints all chars in ChunkyString
*
*/ 
std::ostream& ChunkyString::print(std::ostream& out) const
{
    ConstIterator thisIter = this-> begin();
    while (thisIter != this->end())
    {
        out << (*thisIter);
        ++thisIter;
    }
    return out;
}

/*
* \brief operator+= of ChunkyString
*
* \details adds the chars in rhs to the end of a Chunkysting 
*
*/ 
ChunkyString& ChunkyString::operator+=(const ChunkyString& rhs)
{
    if(rhs.size_ == 0)
    {
        return *this;
    }
    else
    {
        ConstIterator rhsIter = rhs.begin();
        const size_t startSize = rhs.size();
        for(size_t i = 0; i < startSize; ++i)
        {
            push_back(*rhsIter);
            ++rhsIter;
        }
        return *this;
    }       
}

/*
* \brief operator< of ChunkyString
*
* \details iterates through two ChunkStrings and compares the chars in them
*
*/ 
bool ChunkyString::operator<(const ChunkyString& rhs) const
{
    return lexicographical_compare(this->begin(), this->end(), rhs.begin(), rhs.end(), char_traits<char>::lt);

}

/*
* \brief insert function of ChunkyString
*
* \details adds a char before the given iterator
* \param i  iterator that tells us where we want to insert char c
* \param c  char that is to be inserted before i
* \returns an iterator for the ChunkyString pointing to char c in the modified string
*
*/ 
ChunkyString::iterator ChunkyString::insert(iterator i, char c)
{

}

/*
* \brief erase function of ChunkyString
*
* \details erases the char at a given iterator
* \param i  iterator that tells which spot we want to remove the char from
* \returns an iterator for the ChunkyString pointing to the char after i  
*
*/ 
ChunkyString::iterator ChunkyString::erase(iterator i)
{

}

/*
* \brief utilization function of ChunkyString
*
* \details  calculates and returns utilization by dividing the size of a string by
*           the number of Chunks * CHUNKSIZE
*
*/ 
double ChunkyString::utilization() const
{
    double chunksNum = 0; 
    std::list<Chunk>::const_iterator i = chunks_.begin();
    while(i != chunks_.end())
    {
        ++chunksNum;
        ++i;
    }
    return double(size_)/double(chunksNum * Chunk::CHUNKSIZE);
}