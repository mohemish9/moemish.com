/**
 * \file iterator.cpp
 * author: CS70 Starter Code
 *
 * \brief Contains function stubs for the implementation of 
 * ChunkyString::Iterator  and ChunkyString::ConstIterator
 */


#include <stdexcept>
#include "chunkystring.hpp"

using namespace std;
// ----------------------- Iterator stubs: ----------------------
/**
 * \brief Iterator default constructor 
 */
ChunkyString::Iterator::Iterator()
 :index_(0),
  chunk_()
{
    
}

ChunkyString::Iterator::Iterator(const Iterator& rhs)
 :index_(rhs.index_),
  chunk_(rhs.chunk_)
{

}

ChunkyString::Iterator::Iterator(chunk_iter_t a, size_t b)
 :index_(b),
  chunk_(a)
{
    
}

/**
 * \brief Iterator operator++() function
 * \remarks increments the iterator by one
 */
ChunkyString::Iterator& ChunkyString::Iterator::operator++()
{
    if (index_ < chunk_->length_ - 1)
    {
        ++index_;
    }
    else if(index_ == chunk_->length_ - 1)
    {
        ++chunk_;
        index_ = 0;
    }
    return *this;
}

/**
 * \brief Iterator operator--() function
 * \remarks decrements the iterator by one
 */
ChunkyString::Iterator& ChunkyString::Iterator::operator--()
{
    if (index_ > 0)
    {
        --index_;
    }
    else if(index_ == 0)
    {
        --chunk_;
        index_ = chunk_->length_ - 1;
    }
    return *this;
}

/**
 * \brief Iterator operator*() function
 * \remarks deferences the iterator
 * \returns the char at the spot that the iterator is pointing to
 */
ChunkyString::Iterator::reference
    ChunkyString::Iterator::operator*() const
{
    return chunk_->chars_[index_];
}

/**
 * \brief Iterator operator==() function
 * \remarks checks if two iterators are pointing to the same spot (same index_ and same chunks_)
 */
bool ChunkyString::Iterator::operator==(const Iterator& rhs) const
{
    if (this->chunk_ == rhs.chunk_)
    {
      return (this->index_ == rhs.index_);
    }
    return false;
}

/**
 * \brief Iterator operator!=() function
 * \remarks checks if two iterators are not pointing to the same spot (not the same index_ or same chunks_)
 */
bool ChunkyString::Iterator::operator!=(const Iterator& rhs) const
{
    return !(*this == rhs);
}


// ----------------------- ConstIterator stubs: ----------------------
/**
 * \brief ConstIterator default constructor 
 */
ChunkyString::ConstIterator::ConstIterator()
  : index_(),
    chunk_()
{

}
/**
 * \brief ConstIterator constructor 
 * \remarks converts an Iterator into a ConstIterator
 */
ChunkyString::ConstIterator::ConstIterator(const Iterator& i)
 : index_(i.index_),
   chunk_(i.chunk_)
{

}

/**
 * \brief ConstIterator operator++() function
 * \remarks increments the iterator by one
 */
ChunkyString::ConstIterator& ChunkyString::ConstIterator::operator++()
{
    if (index_ < chunk_->length_)
    {
        ++index_;
    }
    else if(index_ == chunk_->length_ - 1)
    {
        ++chunk_;
        index_ = 0;
    }
    return *this;
}

/**
 * \brief Iterator operator--() function
 * \remarks decrements the iterator by one
 */
ChunkyString::ConstIterator& ChunkyString::ConstIterator::operator--()
{
    if (index_ > 0)
    {
        --index_;
    }
    else if(index_ == 0)
    {
        --chunk_;
        index_ = chunk_->length_ - 1;
    }
    return *this;
}

/**
 * \brief Iterator operator*() function
 * \remarks deferences the iterator
 * \returns the char at the spot that the iterator is pointing to
 */
ChunkyString::ConstIterator::reference 
    ChunkyString::ConstIterator::operator*() const
{
    return chunk_->chars_[index_];
}

/**
 * \brief Iterator operator==() function
 * \remarks checks if two iterators are pointing to the same spot (same index_ and same chunks_)
 */
bool ChunkyString::ConstIterator::operator==(const ConstIterator& rhs) const
{
    if (this->chunk_ == rhs.chunk_)
    {
        return (this->index_ == rhs.index_);
    }
    return false;
}

/**
 * \brief Iterator operator!=() function
 * \remarks checks if two iterators are not pointing to the same spot (not the same index_ or same chunks_)
 */
bool ChunkyString::ConstIterator::operator!=(const ConstIterator& rhs) const
{
    return !(*this == rhs);
}
