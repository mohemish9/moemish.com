# Overview

![campbellschunkystring](https://cloud.githubusercontent.com/assets/8798975/10805688/e5cefff0-7d8c-11e5-972b-b8bf31a96b0a.png)

In this assignment, you'll implement a significant portion of the `ChunkyString` class you tested and wrote pseudocode for in the previous assignment. This week, you'll implement all the `ChunkyString` and `ChunkyString::iterator` operations _except_ for `insert` and `erase`. Next week, you'll implement `insert` and `erase`, and use your fully implemented ChunkyString in a program.


# Reading
In addition to reading this assignment, we strongly recommend the following resources:

* Sections 10.4-10.6 of the _C++ Primer 5th edition_, regarding iterators and the Standard Template Library (STL). (See link on Piazza)

* For more information on STL algorithms, check out [http://www.cplusplus.com/reference/algorithm/](http://www.cplusplus.com/reference/algorithm/). It gives good example code; just remember to be careful that you don't copy from or adapt this code. Unfortunately, some iterator functions aren't documented there, but the descriptions in your textbook and elsewhere are okay if you read them carefully.  Just keep iterator-invalidation issues in mind.

# Grading
Your submission will be graded as follows: 
* 17 points: correctness
* 10 points: completeness
* 6 points: style 
* 6 points: elegance
* 6 points: clarity

See the [Grading Guidelines](https://cs.hmc.edu/cs70/wiki/Grading-Guidelines) wiki page for more information about what we're looking for in each of those categories. 
