##order of implementations
```
These functions will be implemented in our cpp file. We will also want to write our own constructor, ChunkyString();, copy constructor, ChunkyString(const ChunkyString& rhs); , assignment operator, and destructor.  The hpp file served as a guide because we knew what functions we needed to write. The order in which the following functions shows up is how we will eventually implement them. 
```

##Implementation
```
ChunkyString::ChunkyString()
{
    define and initialize size_t size_ = 0
    define an empty list of chunks chunks_
}

```
##reasons:
```
It has a size_t (size_) holding the value 0
It has an empty list of chunks (chunks_) 
```

##ChunkyString::Iterator();
##Implementation
```
ChunkyString::Iterator()
{
    define size_t index_ 
    define chunk iterator chunk_
}
```
##reasons:
```
index_ stores where the iterator is in the chunk
chunk_ is the iterator that goes through the linked list of chunks and determines which chunk the iterator is pointing to
```

##ChunkyString::reference operator*();
##Implementation
```
ChunkyString::reference operator*()
{
    returns the value(character) at the index that the chunk_ iterator is pointing at in the ChunkyString
    
}
```
##reasons:
```
Dereferencing the iterator so that we can get the value at the index it's at 

```

##ChunkyString::Iterator& operator--();
##Implementation
```
ChunkyString::Iterator& operator--()
{
    if index_ is larger than 0
        decrement index_ by one
    otherwise, if index_ is 0
        set chunk_ to the previous chunk 
        set index_ to length_
}
```
##reasons:
```
if index_ is greater than zero, the iterator can decrement by minus 1 and stay in the same chunk. 
if index_ is 0, we're jumping back to the previous chunk so we should adjust our private data members accordingly and set index_ to length_ (of the new chunk we're on)

```

##ChunkyString::Iterator& operator++();
##Implementation
```
ChunkyString::Iterator& operator++()
{
    if index_ is smaller than length_
        increment index_ by one
    otherwise, if index_ is equal to length_
        set chunk_ to the next chunk 
        set index_ to 0
}
```
##reasons:
```
if index_ is smaller than length_ (of the chunk we are in), the iterator can increment by 1 and stay in the same chunk. 
if index_ is equal to length_ (of the chunk we are in), we're jumping to the next chunk so we should adjust our private data members accordingly and set index_ to 0
```

##bool operator==(const Iterator& rhs) const
##Implementation
```
bool operator==(const Iterator& rhs) const
{
    Checks the index_ and chunk_ of 'rhs' (another iterator) is equal to the index_ and chunk_ of the current ChunkyString iterator and returns true if they're the same 
}
```
##reasons:
```
We need to make sure the two iterators are pointing at the same index inside the same chunk
```

##bool operator!=(const Iterator& rhs) const
##Implementation
```
bool operator!=(const Iterator& rhs) const
{
    if operator== is false
        return true
    otherwise,
        return false
}
```
##reasons:
```
We need to make sure the two iterators are not pointing at the same index inside the same chunk
```

#ChunkyString::ConstIterator();
##Implementation
```
ChunkyString::ConstIterator()
{
    define size_t index_ 
    define chunk iterator chunk_
}
```
##reasons:
```
index_ stores where the iterator is in the chunk
chunk_ is the iterator that goes through the linked list of chunks and determines which chunk the iterator is pointing to
```

##ChunkyString::reference operator*() const;
##Implementation
```
ChunkyString::reference operator*()
{
    returns a reference to a constant value(character) at the index that the chunk_ iterator is pointing at in the ChunkyString  
}
```
##reasons:
```
    Dereferencing the iterator so that we can get the value at the index it's at without being able to change it
```

##ConstIterator& operator++();
##Implementation
```   
ChunkyString::ConstIterator& operator++()
{
    if index_ is smaller than length_
        increment index_ by one
    otherwise, if index_ is equal to length_
        set chunk_ to the next chunk 
        set index_ to 0
}
```
##reasons:
```
if index_ is smaller than length_ (of the chunk we are in), the iterator can increment by 1 and stay in the same chunk. 
if index_ is equal to length_ (of the chunk we are in), we're jumping to the next chunk so we should adjust our private data members accordingly and set index_ to 0
```

##ConstIterator& operator--();
##Implementation
```   
ChunkyString::ConstIterator& operator--()
{
    if index_ is larger than 0
        decrement index_ by one
    otherwise, if index_ is 0
        set chunk_ to the previous chunk 
        set index_ to length_
}
```
##reasons:
```
if index_ is greater than zero, the iterator can decrement by minus 1 and stay in the same chunk. 
if index_ is 0, we're jumping back to the previous chunk so we should adjust our private data members accordingly and set index_ to length_ (of the new chunk we're on)
```

##bool operator==(const ConstIterator& rhs) const;
##Implementation 
```
    Checks the index_ and chunk_ of 'rhs' (another iterator) is equal to the index_ and chunk_ of the current ChunkyString iterator and returns true if they're the same 
```
##reasons:
```
We need to make sure the two iterators are pointing at the same index inside the same chunk withotu changing any values
```
##bool operator!=(const ConstIterator& rhs) const;
##Implementation 
```
    Checks the index_ and chunk_ of 'rhs' (another iterator) is not equal to the index_ and chunk_ of the current ChunkyString iterator and returns true if they're not the same 
    return the iterator
```
##reasons:
```
We need to make sure the two iterators are not pointing at the same index inside the same chunk without changing any values
```


##iterator ChunkyString::end();
##Implementation:
```
iterator ChunkyString::end()
{
    call the default constructor void ChunkyString::Iterator() to create an empty iterator
    set the iterator chunk_ to be pointing at the last chunk in the list chunks_ (iterate through until you're at the end)
    set the value index_ to the length_ of the chunk in chunk_
    increment the iterator by one 
    return the iterator 
}
```
##reasons:
```
we need to create an empty iterator that points to our current ChunkyString then set chunk_ so that it is pointing at the last chunk in the list chunks_. Then we want to set the value of index_ to length so we know that we're at the last spot (index). Afterwards, we increment that iterator so that we are at the spot after the last spot -- then the iterator is returned
```

##iterator ChunkyString::begin();
##Implementation:
```
iterator ChunkyString::begin()
{
    call the default constructor void ChunkyString::Iterator() to create an empty iterator
    set the iterator chunk_ to be pointing at the first chunk in the list chunks_
    set the value index_ to zero
    return the iterator 
}
```
##reasons:
```
we need to create an empty iterator that points to our current ChunkyString then set chunk_ so that it is pointing at the first chunk in the list chunks_. Then we want to set the value of index_ to 0 so we know that we're at the first spot (index) -- then the iterator is returned
```


##const_iterator cbegin() const; and const_iterator begin() const { return cbegin(); }
##Implementation:
```
ChunkyString::const_iterator cbegin() const
{
    call the default constructor void ChunkyString::Iterator() to create an empty iterator
    set the iterator chunk_ to be pointing at the first chunk in the list chunks_
    set the value index_ to zero
    return the iterator 
}
```
#reasons: 
```
call this when the list you're iterating is going thru has been declared constant. 
we need to create an empty iterator that points to our current ChunkyString then set chunk_ so that it is pointing at the first chunk in the list chunks_. Then we want to set the value of index_ to 0 so we know that we're at the first spot (index) -- then the iterator is returned
```

##const_iterator cend() const; and const_iterator end() const { return cend(); }
##Implementation:
```
ChunkyString::const_iterator cend() const
{
    call the default constructor void ChunkyString::Iterator() to create an empty iterator
    set the iterator chunk_ to be pointing at the last chunk in the list chunks_ (iterate through until you're at the end)
    set the value index_ to the length_ of the chunk in chunk_
    increment the iterator by one 
    return the iterator 
}
```
##reasons:
```
call this when the list you're iterating is going thru has been declared constant. 
we need to create an empty iterator that points to our current ChunkyString then set chunk_ so that it is pointing at the last chunk in the list chunks_. Then we want to set the value of index_ to length so we know that we're at the last spot (index). Afterwards, we increment that iterator so that we are at the spot after the last spot -- then the iterator is returned
```

##void ChunkyString::push_back(char c)
##Implementation:
```
void ChunkyString::push_back(char c)
{
    check if the ChunkyString size_ = 0
        create a new chunk, update size
    
    else if length_  < CHUNKSIZE
        add c to the next open spot (length_ + 1) 
    else (length_ == CHUNKSIZE)
        create a new chunk and update size
        check utilization
            if checkUtilization() returns true
                put c in the first index of the array
            else 
                move some stuff from previous chunk, and add with c into next (new) array
}
```
#reasons:
```
first check if the ChunkyString is empty and if it is, create a new chunk and add c as the first index of the array. If the chunks's length_ is less than CHUNKSIZE, then there's room for us to add c at the end of the chunk so we do that at length_ + 1. Otherwise if length_ == CHUNKSIZE, create a new chunk and checkUtilization(). When that function returns true, just put c in the first index of the new chunk; otherwise, move some stuff from previous chunk into the new chunk too. 
```

##size_t ChunkyString::size() const
##Implementation: 
```
size_t ChunkyString::size() const
{
    return size_;
}
```
#reasons:
```
we made a function to return size_ of a ChunkyString
```

##bool operator==(const ChunkyString& rhs) const
##Implementation: 
```
bool operator==(const ChunkyString& rhs) const
{
    check if this.size_ == rhs.size_
    if true{
        Define and initialize an iterator (thisIter) equal to this.begin()
        Define and initialize an iterator (rhsIter) equal to rhs.begin()
        while both thisIter is not equal to this.end() and rhsIter is not equal to rhs.end(){
            if the value of dereferencing thisIter is equal to the value of defereferencing rhsIter
                increment thisIter and rhsIter
            otherwise
                return false
        }
        return true;
    }
    if false{
        return false;
    }
}
```
#reasons: 
```
checks the size of this and rhs and if not equal, return false because they aren't equal.
Then define and initialize two iterators for this and rhs and have them iterate through both ChunkyStrings while also checking the dereferenced values at each index. as long as they are equal,keep incrementing the iterators and checking; otherwise, return false. 

```
    
##bool operator!=(const ChunkyString& rhs) const;    
##Implementation:
```
bool operator!=(const ChunkyString& rhs) const
{
    if ChunkyString::operator==() const ChunkyString& rhs is true
        return false
    otherwise,
        return true
}
```
##reasons:
```
if sizes of the chunk strings are different then they are not equal and return true;
if any of the chars are not equal in the operator== then return true
if operator== confirmed all chars are equal then return false
```
##std::ostream& print(std::ostream& out) const;      ///< String printing
##Implementation:
```
std::ostream& ChunkySting::print(std::ostream& out)
{
    Define and initialize an iterator (iter) equal to this.begin()
    Define an empty std::ostream& 
    while iter is not equal this.end()
    {
        store the derefenced value that the iter is pointing at in the ostream
        increment iter
    }
    return the ostream

}
```
##reasons:
```
we want to go through every not-empty spot in the chunks and store it in the ostream we are going to return later
```   
##ChunkyString& operator+=(const ChunkyString& rhs);
##Implementation:
```
ChunkyString& operator+=(const ChunkyString& rhs)
{
    if rhs.size_ is zero 
        return this
    else
        Define and initialize an iterator (rhsIter) equal to rhs.begin()
        Define and initialize an iterator (rhsEnd) equal to rhs.end()
        while rhsIter is not equal rhsEnd
            push_back( value of * rhsIter ) which will add the first char in rhs to the end of this and increment the size by 1
            increment rhsIter
        return this
}
```
##reasons:
```
If rhs is empty we only need to return this as it is. Otherwise, we iterate over rhs and add its values at the end of this. Then, return this. 
```
##bool operator<(const ChunkyString& rhs) const;   //returns true if this < rhs 
#Implementation:
```
bool operator<(const ChunkyString& rhs)
{
    for every char1 (deferenced) in current
        for every char2(dereferenced) in rhs 
            if char 1 = char 2 
                increment both char 1 and char 2 and perform check again
            else if char 1 < char 2
                return true 
    return false         
}
```
#reasons:
```
Iterate over chars in this and rhs and compare the values that lay at the same index. 
if they are equal, keep iterating and comparing 
If at any index the char in rhs is bigger than the char in this at the same index, return true
If at any index the char in rhs is smaller than the char in this at the same index, return false
If rhs == this, return false
```
##iterator insert(iterator i, char c);
##Implementation:
```
iterator ChunkyString::insert(char c, iterator i)
{
    if the chunk_ that i is pointing at is full (length_ == CHUNKSIZE)
        if the next chunk contains a free slot
            move the last element in the chunk pointed to by chunk_ to the next chunk
            move all the elements(after i) in the chunk pointed to by chunk_ down the array by one
            set the value of the slot i is pointing to equal to c
        otherwise, if the next chunk is full as well
            create a new chunk and make it the next chunk after the chunk pointed to by chunk_
            move half of the elements in the chunk pointed to by chunk_ to the new chunk
            move the rest of elements in the chunk pointed to by chunk_ down the array by one
            set the value of the slot i is pointing to equal to c
    otherwise, if there are free slot(s) in the chunk_ that i is pointing at
        move the rest of elements in the chunk pointed to by chunk_ down the array by one
        set the value of the slot i is pointing to equal to c
    return an iterator pointing to the slot we edited
}
```
##reasons:
```
if the chunk is not full, we move all the non-empty spots after the one i is pointing at down by one, and we set the value of the spot i is pointing at to c
If the chunk is full, we check the next chunk. If the next chunk is not full, we move the last element in the chunk i is pointing at to the next chunk to make room for the new value to be added. If the next chunk is full, we create a new chunk in between the two full chunks and move half of the stuff in the chunk i is pointing at to the new chunk. Set the value if the char at the spot i is pointing at to c.
Always return a new iterator at the end after all the changes have been made 
this implementation runs by o(1) and meets utilization requirements
```

##iterator erase(iterator i)
##Implementation: 
```
ChunkyString::Iterator erase(iterator i)
{
    if chunk only contains one char
            delete chunk
    otherwise, if chunk contains 1/4 of its capacity
        if the next chunk does not have enough room
            move a part of the elements in the next chunk to the chunk i is pointing to
            delete the contents of the slot i is pointing to
        otherwise, if the next chunk contain enough room  
            move the elements in the current chunk to the next one
            delete the contents of the slot i is pointing to
    otherwise
        delete the contents of the slot i is pointing to
        move any non-empty elements in the same chunk up by one (index minus 1)
}
```
##reasons: 
```
if the chunk only has one char in it, delete the chunk. Otherwise, if the chunk is at 1/4 capacity, if the next chunk is pretty full, move a part of the elements in the next chunk to the chunk that i is poitning at and delete the contents of the slot i is pointing at. if the next chunk has enough room, still holding that the chunk i is pointing at is at 1/4 capacity, then move some of the elements in the current chunk to the next one, and then delete the contents of the slot i is pointing to. for every other case, delete the contents of the slot i is pointing to, move any non-empty elements in the same chunk after the slot i is pointing to up by one 
```

##double utilization() const
##Implementation:
```
double ChunkyString::utilization() const
{
    int numChars (will be a counter for the number of characters in the string);
    Define and initialize at iterator at this.begin() and keep iterating until you reach this.end()
        for every non-empty spot, add 1 to numChars. 
    return double(numChars)/double(chunks_ * CHUNKSIZE);
}
```
##reasons:
```
calculate the number of all the characters in the string so we know what we want utilization to look like. this implementation is constant time. 
```


