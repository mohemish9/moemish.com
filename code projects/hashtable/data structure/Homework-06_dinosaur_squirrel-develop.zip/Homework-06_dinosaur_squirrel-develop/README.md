# Overview

One of the most widely used spelling checkers in unix-like environments is`ispell`, written by our own Professor Kuenning. Is Professor Kuenning's fame and glory deserved? Just how hard *is* it to write a spelling checker?  It's time to find out!

This week, you’ll use a randomized tree (a special type of balanced search tree!) to implement the interface of a spell checker. 

As with any piece of software, you'll need to test and document as you go.


# Readings

In addition to reading this assignment, we recommend the following resources:

* The wiki page on [reading input](https://cs.hmc.edu/cs70/wiki/ReadingInputHowTo)
* The wiki page on [processing command line arguments](https://cs.hmc.edu/cs70/wiki/CommandLineArgumentHowTo)
* Our notes from lab on [implementing trees in C++](https://piazza.com/class_profile/get_resource/jkcywvfuqjyom/jng7rp82zy06lo)
 

# Grading
Your submission will be graded as follows: 
* 18 points: correctness
* 12 points: completeness
* 5 points: style 
* 5 points: elegance
* 5 points: clarity 

See the [Grading Guidelines](https://cs.hmc.edu/cs70/wiki/Grading-Guidelines) wiki page for more information about what we're looking for in each of those categories. 
