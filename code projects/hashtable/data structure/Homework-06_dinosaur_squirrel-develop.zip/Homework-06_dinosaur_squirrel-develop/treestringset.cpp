#include "treestringset.hpp"

#include <string>
#include <random>
#include <iostream>     
#include <algorithm> 

std::knuth_b rand_engine;  // replace knuth_b with one of the engines listed below
std::uniform_real_distribution<> uniform_zero_to_one(0.0, 1.0);


// got it from https://stackoverflow.com/questions/20309009/get-true-or-false-with-a-given-probability
bool random_bool_with_prob( double prob )  // probability between 0.0 and 1.0
{
    return uniform_zero_to_one(rand_engine) >= prob;
}

// zero parameters constructor
TreeStringSet::TreeStringSet()
 : left_(nullptr),
   right_(nullptr),
   root_(nullptr),
   size_(0),
   height_(-1)
   {
       
   }


//destructor
TreeStringSet::~TreeStringSet()
{
  delete root_;
  delete left_;
  delete right_;
}

//size function
size_t TreeStringSet::size() const 
{
  return size_;
}

//insert funtion
void TreeStringSet::insert(const string& myStr)
{
  if (!random_bool_with_prob(1/(size_+1)))
  {
    insertAtRoot(root_ , myStr);
    ++size_;
    height_ = height();
  }
  else if(myStr < root_->value_)
  {
    if (left_ == nullptr)
    {
      left_ = new TreeStringSet;
    }
    left_->insert(myStr);
  }
  else
  {
    if (right_ == nullptr)
    {
      right_ = new TreeStringSet;
    }
    right_->insert(myStr);
  }
  
}

void TreeStringSet::insertAtRoot(Node*& nd, const string& m)
{
  if (nd == nullptr)
  {
    nd = new Node(m, nullptr, nullptr);
  }
  else if (m < nd->value_)
  {
    insertAtRoot(nd->leftNode_, m);
    rotateRight(nd);
  }
  else
  {
     insertAtRoot(nd->rightNode_, m);
     rotateLeft(nd);
  }
}

void TreeStringSet::rotateRight(Node*& top){
  Node* b = top->leftNode_;
  top->leftNode_ = b->rightNode_;
  b->rightNode_ = top;
  top = b;
}
void TreeStringSet::rotateLeft(Node*& top){
  Node* d = top->rightNode_;
  top->rightNode_ = d->leftNode_;
  d->leftNode_ = top;
  top = d;
}

bool TreeStringSet::exists(const string& myStr) const
{
  
   if (root_->value_ == myStr)
   {
      return true;
   }
   else if (left_ == nullptr && right_ == nullptr)
   {
     return false;
   }
   else 
   {
     return left_->exists(myStr) || right_->exists(myStr);
   }
}


int TreeStringSet::height() const
{
  if (this == nullptr)
  {
    return -1;
  }
  else if (left_ == nullptr && right_ == nullptr)
  {
    //this if statment checks if the node that exists is empty (pointing to a nullptr)
    if (root_ == nullptr)
    {
      //if it points to a null ptr we will treat it as if it doesn't exist
      return -1;
    }
    else
    {
      return 0;
    }
  }
  else
  {
    return 1 + max(left_->height(),right_->height());
  }
} 


std::ostream& TreeStringSet::print(std::ostream& out) const
{
  if (this == nullptr)
  {
    out<< "-";
  }
  else if (root_ == nullptr)
  {
    out<< "-";
  }
  else
  {
    out<< "(";
    left_->print(out);
    out<< ", ";
    out<< root_->value_;
    out<<  ", ";
    right_->print(out);
    out<< ")";
  }
  return out;
}

std::ostream& TreeStringSet::showStatistics(std::ostream& out) const
{
  out<< "Tree size: ";
  out<< size_;
  out<< ", Tree height: ";
  out<< height_;
  return out;
}