/**
 * File: myspell.cpp
 *
 * Authors: CS 70 Provided Code 
 *     with additions by ... your CS70 aliases here ...
 *
 * Description: Implements the UI for the spelling checker
 */
#include "treestringset.hpp"
#include <string>
#include <iostream>
#include <stdexcept>
#include <cstddef>
#include <fstream>  

using namespace std;


/**
 * This function processes input from cin and compares against a dictionary
 *        If the word is not found and has not been seen before, spelling
 *        corrections are printed to standard output.
 *
 * Parameters: dictfile - Name of dictionary file.
 *             debug    - Boolean corresponding to the -d flag
 */
void spellcheck(const string& dictfile, bool debug)
{
    TreeStringSet dic;
    std::ifstream dicReader (dictfile, std::ifstream::in);
    while(!dicReader.eof())
    {
       string add;
       std::getline(dicReader, add);
       dic.insert(add);
    }
    if (debug) {
        dic.showStatistics(std::cerr) << endl;
    }
    while(!cin.eof())
    {
        string inputWord = "";
        while(!cin.eof()){
         inputWord += std::tolower(cin.get());
            if(isspace(inputWord.back())){
                break;
            }
            else if ( inputWord.size() > 0 && isalpha(inputWord.back())){
                inputWord.pop_back();
            }
         
        }
        inputWord.pop_back();

        if(!dic.exists(inputWord)){
            cout<< inputWord;
            cout<<": ";
            for (int index = 0; index <inputWord.size(); ++index)
            {
                for (char newChar = 'a'; newChar<= 'z'; ++newChar)
                {
                    string newWord = inputWord;
                    newWord[index] = newChar;
                    if (dic.exists(newWord)){
                        cout<< newWord;
                        cout<< " ";
                    }
                }
                
                
            }
        }
    }
    dicReader.close();
}

// Main function: processes input and runs the spellcheck function
int main(int argc, const char** argv)
{
    bool debug = false;

    // Process command-line options
    --argc; // Skip past 0th arg (program name)
    ++argv;

    // If the user specified debug mode with the -d flag, turn on debugging
    if (argc == 2 && *argv == string("-d")) {
        debug = true;
        --argc;
        ++argv;
    }

    // For correct usage, there should be just one command-line option left
    // If not, print an error to tell the user how they should use this program
    if (argc != 1) {
        cerr << "Usage: ./myspell [-d] dict" << endl;
        exit(2);
    }

    // Check that spelling! Run spellcheck
    try {
        spellcheck(argv[0], debug);
    } catch (std::runtime_error err) {
        cerr << err.what() << endl;
        return 1;
    }

    return 0;
}
