
#include "treestringset.hpp"
#include "testing-logger.hpp"

#include <cstddef>
#include <cstdlib>
#include <iostream>

#include <string>
#include <sstream>
#include <stdexcept>

using namespace std;

bool sizeTest(){
    TestingLogger log("size Test");
    TreeStringSet tree;
    affirm(tree.size() == 0);
    return log.summarize();
}

bool insertTest(){
    TestingLogger log("insert Test");
    TreeStringSet tree;
    affirm(tree.size() == 0);

    tree.insert("first string");
    affirm(tree.size() == 1);
    affirm(tree.height() == 0);
    
    return log.summarize();
}


bool existsTest(){
    TestingLogger log("exists Test");
    TreeStringSet tree;
    affirm(tree.size() == 0);

    tree.insert("first string");
    affirm(tree.size() == 1);
    affirm(tree.exists("first string"));
    return log.summarize();
}

bool heightTest(){
    TestingLogger log("height Test");
    TreeStringSet tree;
    affirm(tree.height()==-1); // in this case the node exists but it points to nullptr so we will treat it as if it doesn't exist

    tree.insert("b");
    affirm(tree.height()==0);

    tree.insert("c");
    affirm(tree.height()==1);

    tree.insert("a");
    affirm(tree.height()==1);

    tree.insert("f");
    affirm(tree.height()==2);
    return log.summarize();
}

bool printTest(){
    TestingLogger log("print Test");
    TreeStringSet tree;
    stringstream out;
    tree.print(out);
    affirm(out.str() == "-");

    tree.insert("b");
    tree.insert("c");
    tree.insert("a");
    stringstream out2;
    tree.print(out2);

    affirm( out2.str() == "((-, a, -), b, (-, c, -))");
    return log.summarize();
}

bool showStatisticsTest(){
    TestingLogger log("show Statistics Test");
    TreeStringSet tree;
    stringstream out;
    tree.showStatistics(out);
    affirm(out.str() == "Tree size: 0, Tree height: -1");

    tree.insert("b");   
    stringstream out2;
    tree.showStatistics(out2);

    affirm( out2.str() == "Tree size: 1, Tree height: 0");
    return log.summarize();
}

int main(int, char**)
{
    TestingLogger alltests("All tests");
    
    affirm(sizeTest());
    affirm(insertTest());
    affirm(existsTest());
    affirm(heightTest());
    affirm(printTest());
    affirm(showStatisticsTest());
    // To do: add your new tests as new affirms here...
    
    // Print a summary of the all the affirmations and exit the program.

    if (alltests.summarize(true)) {
        return 0;       // Error code of 0 == Success!
    } else {
        return 2;       // Arbitrarily chosen exit code of 2 means tests failed.
    }
}