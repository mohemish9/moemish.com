#ifndef STRINGUTIL_CPP_INCLUDED
#define STRINGUTIL_CPP_INCLUDED 1

#include <string>

using namespace std;

class TreeStringSet {
    public:
        TreeStringSet();
        ~TreeStringSet();
        size_t size() const;
        void insert(const string&);
        bool exists(const string&) const;
        int height() const;
        std::ostream& print(std::ostream& out) const;
        std::ostream& showStatistics(std::ostream& out) const;

        
    private:
    TreeStringSet* left_;
    TreeStringSet* right_;
    struct Node
    {
        string value_;
        Node* leftNode_ ;
        Node* rightNode_ ;

        Node(string value, Node* leftNode, Node* rightNode)
        : value_(value),
        leftNode_(leftNode),
        rightNode_(rightNode)
        {

        }
    };
    Node* root_;
    
    size_t size_;
    int height_;
    
    
    static void insertAtRoot(Node*& nd, const string& m);
    static void rotateRight(Node*& top);
    static void rotateLeft(Node*& top);
};
#endif
